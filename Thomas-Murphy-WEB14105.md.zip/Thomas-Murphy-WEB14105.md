## WEB14105: Web Development Workshop


**Name:** Thomas Murphy

**Student No:** 96292115

**Course:** BA (Hons) Web Media, Level 1

**Unit Code:** WEB14105





###Video Presentation Link - 

1. [Youtube](https://www.youtube.com/watch?v=XVDEfTVvBK4)


### Links


1. [Content Stratergy](https://docs.google.com/document/d/1bb7RBsbFnGIpfHBpdS89dRohaZH6sn49ak9cEysHHU4/edit)


1. [Research](https://docs.google.com/document/d/1W1E2fEb_nxZXqGrCBlvQMa16FO2MD-ka2Eiu1dU2jg0/edit)


2. [Github Repository](https://github.com/thomass96/Sharing-Is-Caring)

3. [Work In Porgress - Github Pages](http://thomass96.github.io/Sharing-Is-Caring/)

